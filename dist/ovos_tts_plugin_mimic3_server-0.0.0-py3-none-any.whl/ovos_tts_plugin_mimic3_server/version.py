# The following lines are replaced during the release process.
# START_VERSION_BLOCK
VERSION_MAJOR = 0
VERSION_MINOR = 0
VERSION_BUILD = 0
VERSION_ALPHA = 0
# END_VERSION_BLOCK
